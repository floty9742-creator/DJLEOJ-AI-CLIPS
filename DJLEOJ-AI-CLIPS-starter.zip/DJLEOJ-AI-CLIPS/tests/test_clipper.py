import unittest
from unittest.mock import patch
from pathlib import Path
from tempfile import TemporaryDirectory
from clipper import export_clips


class ClipperTests(unittest.TestCase):
    def test_invalid_length(self):
        with patch('clipper.require_tool'):
            with self.assertRaises(ValueError):
                
                with TemporaryDirectory() as tmp:
                    source = Path(tmp) / 'input.mp4'
                    source.touch()
                    export_clips(source, Path(tmp) / 'out', length=0)

    def test_missing_source(self):
        with patch('clipper.require_tool'):
            with TemporaryDirectory() as tmp:
                with self.assertRaises(FileNotFoundError):
                    export_clips(Path(tmp) / 'missing.mp4', Path(tmp) / 'out')


if __name__ == '__main__':
    unittest.main()
