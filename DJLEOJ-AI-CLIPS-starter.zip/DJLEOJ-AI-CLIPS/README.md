# DJLEOJ AI CLIPS

An early-stage open-source video clipping toolkit for independent creators.

## Current features

- Split a **local video file** into consecutive MP4 clips using FFmpeg.
- Choose clip duration and maximum number of clips.
- Optionally center-crop clips to vertical 9:16 at 1080 × 1920.

**Status:** This is an initial command-line prototype. It does **not** yet detect highlights, transcribe audio, generate subtitles, download YouTube videos, or use AI. Those are possible future features, not existing capabilities.

## Requirements

- Python 3.9+
- FFmpeg and FFprobe installed and available on your PATH

## Usage

```bash
python clipper.py input.mp4 --length 30 --output clips
python clipper.py input.mp4 --length 45 --limit 3 --vertical
```

The vertical option uses a center crop and may cut off subjects near the edges. Only process videos you own or are authorized to use.

## Roadmap

- Add optional scene-change detection
- Add subtitle generation
- Add a local web interface
- Explore optional AI-assisted highlight ranking

## Contributing

Issues and pull requests are welcome. Please describe changes clearly and test locally before submitting.

## License

MIT (see LICENSE).
