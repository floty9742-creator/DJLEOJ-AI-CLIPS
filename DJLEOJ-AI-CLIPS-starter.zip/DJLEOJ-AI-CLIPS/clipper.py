"""Simple local video segment exporter using FFmpeg."""
import argparse
import json
import shutil
import subprocess
from pathlib import Path


def require_tool(name):
    if not shutil.which(name):
        raise RuntimeError(f"{name} is not installed or not on PATH")


def duration_seconds(path):
    result = subprocess.run([
        'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
        '-of', 'json', str(path)
    ], capture_output=True, text=True, check=True)
    return float(json.loads(result.stdout)['format']['duration'])


def export_clips(source, output, length=30, limit=None, vertical=False):
    require_tool('ffmpeg')
    require_tool('ffprobe')
    source = Path(source)
    if not source.is_file():
        raise FileNotFoundError(source)
    if length <= 0 or (limit is not None and limit <= 0):
        raise ValueError('Clip length and limit must be positive')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    duration = duration_seconds(source)
    count = 0
    start = 0.0
    while start < duration and (limit is None or count < limit):
        count += 1
        segment_length = min(length, duration - start)
        target = output / f'clip_{count:03d}.mp4'
        command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                   '-ss', str(start), '-i', str(source), '-t', str(segment_length)]
        if vertical:
            command += ['-vf', 'scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920']
        command += ['-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
                    '-c:a', 'aac', '-movflags', '+faststart', str(target)]
        subprocess.run(command, check=True)
        print(f'Created {target}')
        start += length
    return count


def main():
    parser = argparse.ArgumentParser(description='Split a local video into clips using FFmpeg')
    parser.add_argument('video', help='Path to a local video file')
    parser.add_argument('--output', default='clips', help='Output directory')
    parser.add_argument('--length', type=float, default=30, help='Seconds per clip (default 30)')
    parser.add_argument('--limit', type=int, default=None, help='Maximum number of clips')
    parser.add_argument('--vertical', action='store_true', help='Center crop to 1080x1920 (9:16)')
    args = parser.parse_args()
    try:
        export_clips(args.video, args.output, args.length, args.limit, args.vertical)
    except (RuntimeError, ValueError, FileNotFoundError, subprocess.CalledProcessError, KeyError) as exc:
        parser.exit(1, f'Error: {exc}\n')


if __name__ == '__main__':
    main()
